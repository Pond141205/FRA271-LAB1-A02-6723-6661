# FRA-271_Lab1_Sensors
The folder contains IOC (STM32) and Simulink files for the following labs:  
- **ADC Reader** → Labs 1.1, 1.3, 1.4  
- **Encoder Reader** → Lab 1.2  

Note: These files are provided as simple examples to help you get started with the labs.  
You are expected to modify and extend them as needed to fully meet the lab requirements.  