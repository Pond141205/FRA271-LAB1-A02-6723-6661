/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder_reader_simulink.c
 *
 * Code generated for Simulink model 'Encoder_reader_simulink'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Tue Oct 28 06:09:19 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Encoder_reader_simulink.h"
#include "rtwtypes.h"
#include "Encoder_reader_simulink_types.h"
#include "Encoder_reader_simulink_private.h"
#include "stm_timer_ll.h"

/* Named constants for MATLAB Function: '<Root>/Polling_x1' */
#define Encoder_reader_simul_CALL_EVENT (-1)

/* Named constants for MATLAB Function: '<Root>/WrapAround1' */
#define Encoder_reader_sim_CALL_EVENT_c (-1)

/* Block signals (default storage) */
B_Encoder_reader_simulink_T Encoder_reader_simulink_B;

/* Block states (default storage) */
DW_Encoder_reader_simulink_T Encoder_reader_simulink_DW;

/* Real-time model */
static RT_MODEL_Encoder_reader_simul_T Encoder_reader_simulink_M_;
RT_MODEL_Encoder_reader_simul_T *const Encoder_reader_simulink_M =
  &Encoder_reader_simulink_M_;

/* Forward declaration for local functions */
static void Encoder_read_SystemCore_setup_j(stm32cube_blocks_EncoderBlock_T *obj);
static void Encoder_reader_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);
static void Encoder_rea_SystemCore_setup_j2(stm32cube_blocks_EncoderBlock_T *obj);

/*
 * System initialize for atomic system:
 *    '<Root>/Polling_x1'
 *    '<Root>/Polling_x2'
 *    '<Root>/Polling_x4'
 */
void Encoder_reader__Polling_x1_Init(DW_Polling_x1_Encoder_reader__T *localDW)
{
  int32_T i;
  static const int8_T tmp[16] = { 0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1,
    -1, 0 };

  for (i = 0; i < 16; i++) {
    localDW->lookup_table[i] = tmp[i];
  }

  localDW->sfEvent = Encoder_reader_simul_CALL_EVENT;
}

/*
 * Output and update for atomic system:
 *    '<Root>/Polling_x1'
 *    '<Root>/Polling_x2'
 *    '<Root>/Polling_x4'
 */
void Encoder_reader_simul_Polling_x1(boolean_T rtu_Pin_A, boolean_T rtu_Pin_B,
  real_T rtu_mode, real_T rtu_dt, int32_T *rty_position, real_T *rty_velocity,
  boolean_T *rty_pulse, DW_Polling_x1_Encoder_reader__T *localDW)
{
  int32_T change;
  localDW->sfEvent = Encoder_reader_simul_CALL_EVENT;
  if (!localDW->pos_not_empty) {
    localDW->last_A = rtu_Pin_A;
    localDW->last_A_not_empty = true;
    localDW->last_B = rtu_Pin_B;
    localDW->last_B_not_empty = true;
    localDW->pos_not_empty = true;
    localDW->lookup_table_not_empty = true;
  }

  change = 0;
  switch ((int32_T)rtu_mode) {
   case 1:
    if (rtu_Pin_A && (!localDW->last_A)) {
      if (!rtu_Pin_B) {
        change = 1;
      } else {
        change = -1;
      }
    }
    break;

   case 2:
    if (rtu_Pin_A != localDW->last_A) {
      if (rtu_Pin_A != rtu_Pin_B) {
        change = 1;
      } else {
        change = -1;
      }
    }
    break;

   case 4:
    change = localDW->lookup_table[(localDW->last_A << 3 != 0) ||
      (localDW->last_B << 2 != 0) || (rtu_Pin_A << 1 != 0) || rtu_Pin_B];
    break;
  }

  if ((localDW->pos < 0) && (change < MIN_int32_T - localDW->pos)) {
    localDW->pos = MIN_int32_T;
  } else if ((localDW->pos > 0) && (change > MAX_int32_T - localDW->pos)) {
    localDW->pos = MAX_int32_T;
  } else {
    localDW->pos += change;
  }

  if (rtu_dt > 0.0) {
    *rty_velocity = (real_T)change / rtu_dt;
  } else {
    *rty_velocity = 0.0;
  }

  localDW->last_A = rtu_Pin_A;
  localDW->last_B = rtu_Pin_B;
  *rty_position = localDW->pos;
  *rty_pulse = rtu_Pin_A;
}

/*
 * System initialize for atomic system:
 *    '<Root>/WrapAround1'
 *    '<Root>/WrapAround2'
 */
void Encoder_reader_WrapAround1_Init(DW_WrapAround1_Encoder_reader_T *localDW)
{
  localDW->sfEvent = Encoder_reader_sim_CALL_EVENT_c;
}

/*
 * Output and update for atomic system:
 *    '<Root>/WrapAround1'
 *    '<Root>/WrapAround2'
 */
void Encoder_reader_simu_WrapAround1(real_T rtu_encoder_Signal, real_T
  rtu_max_Counts, real_T rtu_dt, real_T *rty_Position, real_T *rty_Velocity,
  real_T *rty_Pulse, DW_WrapAround1_Encoder_reader_T *localDW)
{
  real_T delta;
  localDW->sfEvent = Encoder_reader_sim_CALL_EVENT_c;
  if (!localDW->prev_Signal_not_empty) {
    localDW->prev_Signal = rtu_encoder_Signal;
    localDW->prev_Signal_not_empty = true;
    localDW->corrected_Sum = rtu_encoder_Signal;
    localDW->corrected_Sum_not_empty = true;
  }

  delta = rtu_encoder_Signal - localDW->prev_Signal;
  if (delta < -rtu_max_Counts / 2.0) {
    delta += rtu_max_Counts;
  } else if (delta > rtu_max_Counts / 2.0) {
    delta -= rtu_max_Counts;
  }

  localDW->corrected_Sum += delta;
  if (rtu_dt > 0.0) {
    *rty_Velocity = delta / rtu_dt;
  } else {
    *rty_Velocity = 0.0;
  }

  localDW->prev_Signal = rtu_encoder_Signal;
  *rty_Position = localDW->corrected_Sum;
  *rty_Pulse = rtu_encoder_Signal;
}

static void Encoder_read_SystemCore_setup_j(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void Encoder_reader_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM1;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void Encoder_rea_SystemCore_setup_j2(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/TIM8_Encode_x4' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM8;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/TIM8_Encode_x4' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/TIM8_Encode_x4' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/TIM8_Encode_x4' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void Encoder_reader_simulink_step(void)
{
  real_T Position_k;
  real_T Pulse_f;
  real_T delta;
  int32_T position;
  uint32_T pinReadLoc;
  boolean_T pulse;

  /* MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  Encoder_reader_simulink_B.TIM3_Encoder_x1 = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj_p.TimerHandle, false, NULL);

  /* MATLAB Function: '<Root>/WrapAround' incorporates:
   *  Constant: '<Root>/Constant'
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  if (!Encoder_reader_simulink_DW.prev_Signal_not_empty) {
    Encoder_reader_simulink_DW.prev_Signal =
      Encoder_reader_simulink_B.TIM3_Encoder_x1;
    Encoder_reader_simulink_DW.prev_Signal_not_empty = true;
    Encoder_reader_simulink_DW.corrected_Sum =
      Encoder_reader_simulink_B.TIM3_Encoder_x1;
  }

  delta = (real_T)Encoder_reader_simulink_B.TIM3_Encoder_x1 -
    Encoder_reader_simulink_DW.prev_Signal;
  if (delta < -32767.5) {
    delta += 65535.0;
  } else if (delta > 32767.5) {
    delta -= 65535.0;
  }

  Encoder_reader_simulink_DW.corrected_Sum += delta;
  Encoder_reader_simulink_DW.prev_Signal =
    Encoder_reader_simulink_B.TIM3_Encoder_x1;

  /* Gain: '<Root>/Gain' incorporates:
   *  MATLAB Function: '<Root>/WrapAround'
   */
  Encoder_reader_simulink_B.position_x1_QEI = 0.26179938779914941 *
    Encoder_reader_simulink_DW.corrected_Sum;

  /* Gain: '<Root>/Gain1' incorporates:
   *  Constant: '<Root>/Constant1'
   *  MATLAB Function: '<Root>/WrapAround'
   */
  Encoder_reader_simulink_B.velocity_x1_QEI = delta / 0.1 * 0.26179938779914941;

  /* MATLABSystem: '<S10>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOA);

  /* MATLABSystem: '<S10>/Digital Port Read' */
  Encoder_reader_simulink_B.DigitalPortRead_o = ((pinReadLoc & 256U) != 0U);

  /* MATLABSystem: '<S12>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* MATLABSystem: '<S12>/Digital Port Read' */
  Encoder_reader_simulink_B.DigitalPortRead = ((pinReadLoc & 1024U) != 0U);

  /* MATLAB Function: '<Root>/Polling_x4' incorporates:
   *  Constant: '<Root>/Constant10'
   *  Constant: '<Root>/Constant11'
   */
  Encoder_reader_simul_Polling_x1(Encoder_reader_simulink_B.DigitalPortRead_o,
    Encoder_reader_simulink_B.DigitalPortRead, 4.0, 0.1, &position, &delta,
    &pulse, &Encoder_reader_simulink_DW.sf_Polling_x4);

  /* Gain: '<Root>/Gain11' */
  Encoder_reader_simulink_B.velocity_x4_Polling = pulse ? 9658692610769496064ULL
    : 0ULL;

  /* Gain: '<Root>/Gain10' */
  Encoder_reader_simulink_B.position_x4_Polling = 0.065449846949787352 * delta;

  /* MATLAB Function: '<Root>/Polling_x1' incorporates:
   *  Constant: '<Root>/Constant6'
   *  Constant: '<Root>/Constant7'
   */
  Encoder_reader_simul_Polling_x1(Encoder_reader_simulink_B.DigitalPortRead_o,
    Encoder_reader_simulink_B.DigitalPortRead, 1.0, 0.1, &position, &delta,
    &pulse, &Encoder_reader_simulink_DW.sf_Polling_x1);

  /* Gain: '<Root>/Gain6' */
  Encoder_reader_simulink_B.position_x1_Polling = 1124419809LL * position;

  /* Gain: '<Root>/Gain7' */
  Encoder_reader_simulink_B.velocity_x1_Polling = 0.26179938779914941 * delta;

  /* MATLAB Function: '<Root>/Polling_x2' incorporates:
   *  Constant: '<Root>/Constant8'
   *  Constant: '<Root>/Constant9'
   */
  Encoder_reader_simul_Polling_x1(Encoder_reader_simulink_B.DigitalPortRead_o,
    Encoder_reader_simulink_B.DigitalPortRead, 2.0, 0.1, &position, &delta,
    &pulse, &Encoder_reader_simulink_DW.sf_Polling_x2);

  /* Gain: '<Root>/Gain9' */
  Encoder_reader_simulink_B.velocity_x2_Polling = pulse ? 9658692610769496064ULL
    : 0ULL;

  /* Gain: '<Root>/Gain8' */
  Encoder_reader_simulink_B.position_x2_Polling = 0.1308996938995747 * delta;

  /* MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  Encoder_reader_simulink_B.TIM1_Encoder_x2 = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj_g.TimerHandle, false, NULL);

  /* MATLAB Function: '<Root>/WrapAround1' incorporates:
   *  Constant: '<Root>/Constant2'
   *  Constant: '<Root>/Constant3'
   *  DataTypeConversion: '<Root>/Data Type Conversion2'
   */
  Encoder_reader_simu_WrapAround1((real_T)
    Encoder_reader_simulink_B.TIM1_Encoder_x2, 65535.0, 0.1, &Position_k, &delta,
    &Pulse_f, &Encoder_reader_simulink_DW.sf_WrapAround1);

  /* Gain: '<Root>/Gain2' */
  Encoder_reader_simulink_B.position_x2_QEI = 0.1308996938995747 * Position_k;

  /* Gain: '<Root>/Gain3' */
  Encoder_reader_simulink_B.velocity_x2_QEI = 0.1308996938995747 * delta;

  /* MATLABSystem: '<Root>/TIM8_Encode_x4' */
  Encoder_reader_simulink_B.TIM8_Encode_x4 = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj_k.TimerHandle, false, NULL);

  /* MATLAB Function: '<Root>/WrapAround2' incorporates:
   *  Constant: '<Root>/Constant4'
   *  Constant: '<Root>/Constant5'
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   */
  Encoder_reader_simu_WrapAround1((real_T)
    Encoder_reader_simulink_B.TIM8_Encode_x4, 65535.0, 0.1, &Position_k, &delta,
    &Pulse_f, &Encoder_reader_simulink_DW.sf_WrapAround2);

  /* Gain: '<Root>/Gain4' */
  Encoder_reader_simulink_B.position_x4_QEI = 0.065449846949787352 * Position_k;

  /* Gain: '<Root>/Gain5' */
  Encoder_reader_simulink_B.velocity_x4_QEI = 0.065449846949787352 * delta;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  Encoder_reader_simulink_M->Timing.taskTime0 =
    ((time_T)(++Encoder_reader_simulink_M->Timing.clockTick0)) *
    Encoder_reader_simulink_M->Timing.stepSize0;
}

/* Model initialize function */
void Encoder_reader_simulink_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(Encoder_reader_simulink_M, 100.0);
  Encoder_reader_simulink_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  Encoder_reader_simulink_M->Sizes.checksums[0] = (2866064132U);
  Encoder_reader_simulink_M->Sizes.checksums[1] = (1715940651U);
  Encoder_reader_simulink_M->Sizes.checksums[2] = (762259626U);
  Encoder_reader_simulink_M->Sizes.checksums[3] = (3624214405U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[12];
    Encoder_reader_simulink_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Encoder_reader_simulink_M->extModeInfo,
      &Encoder_reader_simulink_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Encoder_reader_simulink_M->extModeInfo,
                        Encoder_reader_simulink_M->Sizes.checksums);
    rteiSetTPtr(Encoder_reader_simulink_M->extModeInfo, rtmGetTPtr
                (Encoder_reader_simulink_M));
  }

  /* SystemInitialize for MATLAB Function: '<Root>/Polling_x4' */
  Encoder_reader__Polling_x1_Init(&Encoder_reader_simulink_DW.sf_Polling_x4);

  /* SystemInitialize for MATLAB Function: '<Root>/Polling_x1' */
  Encoder_reader__Polling_x1_Init(&Encoder_reader_simulink_DW.sf_Polling_x1);

  /* SystemInitialize for MATLAB Function: '<Root>/Polling_x2' */
  Encoder_reader__Polling_x1_Init(&Encoder_reader_simulink_DW.sf_Polling_x2);

  /* SystemInitialize for MATLAB Function: '<Root>/WrapAround1' */
  Encoder_reader_WrapAround1_Init(&Encoder_reader_simulink_DW.sf_WrapAround1);

  /* SystemInitialize for MATLAB Function: '<Root>/WrapAround2' */
  Encoder_reader_WrapAround1_Init(&Encoder_reader_simulink_DW.sf_WrapAround2);

  /* Start for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  Encoder_reader_simulink_DW.obj_p.isInitialized = 0;
  Encoder_reader_simulink_DW.obj_p.matlabCodegenIsDeleted = false;
  Encoder_read_SystemCore_setup_j(&Encoder_reader_simulink_DW.obj_p);

  /* Start for MATLABSystem: '<S10>/Digital Port Read' */
  Encoder_reader_simulink_DW.obj_i.matlabCodegenIsDeleted = false;
  Encoder_reader_simulink_DW.obj_i.isInitialized = 1;
  Encoder_reader_simulink_DW.obj_i.isSetupComplete = true;

  /* Start for MATLABSystem: '<S12>/Digital Port Read' */
  Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted = false;
  Encoder_reader_simulink_DW.obj.isInitialized = 1;
  Encoder_reader_simulink_DW.obj.isSetupComplete = true;

  /* Start for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  Encoder_reader_simulink_DW.obj_g.isInitialized = 0;
  Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted = false;
  Encoder_reader_SystemCore_setup(&Encoder_reader_simulink_DW.obj_g);

  /* Start for MATLABSystem: '<Root>/TIM8_Encode_x4' */
  Encoder_reader_simulink_DW.obj_k.isInitialized = 0;
  Encoder_reader_simulink_DW.obj_k.matlabCodegenIsDeleted = false;
  Encoder_rea_SystemCore_setup_j2(&Encoder_reader_simulink_DW.obj_k);
}

/* Model terminate function */
void Encoder_reader_simulink_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  if (!Encoder_reader_simulink_DW.obj_p.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_p.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj_p.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj_p.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj_p.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj_p.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj_p.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj_p.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/TIM3_Encoder_x1' */
  /* Terminate for MATLABSystem: '<S10>/Digital Port Read' */
  if (!Encoder_reader_simulink_DW.obj_i.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_i.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S10>/Digital Port Read' */

  /* Terminate for MATLABSystem: '<S12>/Digital Port Read' */
  if (!Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S12>/Digital Port Read' */
  /* Terminate for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  if (!Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj_g.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj_g.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj_g.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj_g.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj_g.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj_g.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/TIM1_Encoder_x2' */
  /* Terminate for MATLABSystem: '<Root>/TIM8_Encode_x4' */
  if (!Encoder_reader_simulink_DW.obj_k.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_k.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj_k.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj_k.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj_k.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj_k.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj_k.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj_k.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/TIM8_Encode_x4' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
