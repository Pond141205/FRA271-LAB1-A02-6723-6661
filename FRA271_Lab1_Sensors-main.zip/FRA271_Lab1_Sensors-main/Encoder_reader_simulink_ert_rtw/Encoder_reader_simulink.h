/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder_reader_simulink.h
 *
 * Code generated for Simulink model 'Encoder_reader_simulink'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Tue Oct 28 06:09:19 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Encoder_reader_simulink_h_
#define Encoder_reader_simulink_h_
#ifndef Encoder_reader_simulink_COMMON_INCLUDES_
#define Encoder_reader_simulink_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "math.h"
#include "main.h"
#include "mw_stm32_utils.h"
#endif                            /* Encoder_reader_simulink_COMMON_INCLUDES_ */

#include "Encoder_reader_simulink_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block states (default storage) for system '<Root>/Polling_x1' */
typedef struct {
  int32_T sfEvent;                     /* '<Root>/Polling_x1' */
  int32_T pos;                         /* '<Root>/Polling_x1' */
  int8_T lookup_table[16];             /* '<Root>/Polling_x1' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/Polling_x1' */
  boolean_T last_A;                    /* '<Root>/Polling_x1' */
  boolean_T last_A_not_empty;          /* '<Root>/Polling_x1' */
  boolean_T last_B;                    /* '<Root>/Polling_x1' */
  boolean_T last_B_not_empty;          /* '<Root>/Polling_x1' */
  boolean_T pos_not_empty;             /* '<Root>/Polling_x1' */
  boolean_T lookup_table_not_empty;    /* '<Root>/Polling_x1' */
} DW_Polling_x1_Encoder_reader__T;

/* Block states (default storage) for system '<Root>/WrapAround1' */
typedef struct {
  real_T prev_Signal;                  /* '<Root>/WrapAround1' */
  real_T corrected_Sum;                /* '<Root>/WrapAround1' */
  int32_T sfEvent;                     /* '<Root>/WrapAround1' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/WrapAround1' */
  boolean_T prev_Signal_not_empty;     /* '<Root>/WrapAround1' */
  boolean_T corrected_Sum_not_empty;   /* '<Root>/WrapAround1' */
} DW_WrapAround1_Encoder_reader_T;

/* Block signals (default storage) */
typedef struct {
  uint64_T velocity_x4_Polling;        /* '<Root>/Gain11' */
  uint64_T velocity_x2_Polling;        /* '<Root>/Gain9' */
  int64_T position_x1_Polling;         /* '<Root>/Gain6' */
  real_T position_x1_QEI;              /* '<Root>/Gain' */
  real_T velocity_x1_QEI;              /* '<Root>/Gain1' */
  real_T position_x4_Polling;          /* '<Root>/Gain10' */
  real_T velocity_x1_Polling;          /* '<Root>/Gain7' */
  real_T position_x2_Polling;          /* '<Root>/Gain8' */
  real_T position_x2_QEI;              /* '<Root>/Gain2' */
  real_T velocity_x2_QEI;              /* '<Root>/Gain3' */
  real_T position_x4_QEI;              /* '<Root>/Gain4' */
  real_T velocity_x4_QEI;              /* '<Root>/Gain5' */
  uint32_T TIM8_Encode_x4;             /* '<Root>/TIM8_Encode_x4' */
  uint32_T TIM3_Encoder_x1;            /* '<Root>/TIM3_Encoder_x1' */
  uint32_T TIM1_Encoder_x2;            /* '<Root>/TIM1_Encoder_x2' */
  boolean_T DigitalPortRead;           /* '<S12>/Digital Port Read' */
  boolean_T DigitalPortRead_o;         /* '<S10>/Digital Port Read' */
} B_Encoder_reader_simulink_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_DigitalPortR_T obj; /* '<S12>/Digital Port Read' */
  stm32cube_blocks_DigitalPortR_T obj_i;/* '<S10>/Digital Port Read' */
  stm32cube_blocks_EncoderBlock_T obj_k;/* '<Root>/TIM8_Encode_x4' */
  stm32cube_blocks_EncoderBlock_T obj_p;/* '<Root>/TIM3_Encoder_x1' */
  stm32cube_blocks_EncoderBlock_T obj_g;/* '<Root>/TIM1_Encoder_x2' */
  real_T prev_Signal;                  /* '<Root>/WrapAround' */
  real_T corrected_Sum;                /* '<Root>/WrapAround' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/WrapAround' */
  boolean_T prev_Signal_not_empty;     /* '<Root>/WrapAround' */
  DW_WrapAround1_Encoder_reader_T sf_WrapAround2;/* '<Root>/WrapAround2' */
  DW_WrapAround1_Encoder_reader_T sf_WrapAround1;/* '<Root>/WrapAround1' */
  DW_Polling_x1_Encoder_reader__T sf_Polling_x4;/* '<Root>/Polling_x4' */
  DW_Polling_x1_Encoder_reader__T sf_Polling_x2;/* '<Root>/Polling_x2' */
  DW_Polling_x1_Encoder_reader__T sf_Polling_x1;/* '<Root>/Polling_x1' */
} DW_Encoder_reader_simulink_T;

/* Real-time Model Data Structure */
struct tag_RTM_Encoder_reader_simuli_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_Encoder_reader_simulink_T Encoder_reader_simulink_B;

/* Block states (default storage) */
extern DW_Encoder_reader_simulink_T Encoder_reader_simulink_DW;

/* Model entry point functions */
extern void Encoder_reader_simulink_initialize(void);
extern void Encoder_reader_simulink_step(void);
extern void Encoder_reader_simulink_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Encoder_reader_simul_T *const Encoder_reader_simulink_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Encoder_reader_simulink'
 * '<S1>'   : 'Encoder_reader_simulink/INA'
 * '<S2>'   : 'Encoder_reader_simulink/INB'
 * '<S3>'   : 'Encoder_reader_simulink/Polling_x1'
 * '<S4>'   : 'Encoder_reader_simulink/Polling_x2'
 * '<S5>'   : 'Encoder_reader_simulink/Polling_x4'
 * '<S6>'   : 'Encoder_reader_simulink/WrapAround'
 * '<S7>'   : 'Encoder_reader_simulink/WrapAround1'
 * '<S8>'   : 'Encoder_reader_simulink/WrapAround2'
 * '<S9>'   : 'Encoder_reader_simulink/INA/ECSoC'
 * '<S10>'  : 'Encoder_reader_simulink/INA/ECSoC/ECSimCodegen'
 * '<S11>'  : 'Encoder_reader_simulink/INB/ECSoC'
 * '<S12>'  : 'Encoder_reader_simulink/INB/ECSoC/ECSimCodegen'
 */
#endif                                 /* Encoder_reader_simulink_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
